This work is licensed under a [Creative Commons Attribution NonCommercial ShareAlike 3.0 Unported](http://creativecommons.org/licenses/by-nc-sa/3.0/) License.
